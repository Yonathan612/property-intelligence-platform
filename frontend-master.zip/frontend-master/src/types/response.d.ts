export type ErrorResponse = {
  success: boolean;
  error: string;
  type: string;
  code: string;
};
